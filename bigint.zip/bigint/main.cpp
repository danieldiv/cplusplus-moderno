#include "bigint.hpp"

// subtracao nao esta funcionando corretamente
// valores devem ser positivos

int main() {
    BigInt a("100000");
    BigInt b("98657");
    const BigInt unitario("1");
    const BigInt dobro("2");

    BigInt c = a + b + unitario;
    cout << "[+] = " << c.getVal() << endl;

    BigInt d = (a - b + unitario) * dobro;
    cout << "[-] = " << d.getVal() << endl;

    BigInt f = b * unitario;
    cout << "[*] = " << f.getVal() << endl;

    BigInt g = a / b;
    cout << "[/] = " << g.getVal() << endl;

    BigInt h = b / a;
    cout << "[/] = " << h.getVal() << endl;

    return 0;
}